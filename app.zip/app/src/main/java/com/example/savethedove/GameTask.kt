package com.example.savethedove

interface GameTask {
    fun closeGame(mScore:Int)
}
